// 导航栏 
    window.onload = function(){
        function $(id){
            return typeof id==='string'?document.getElementById(id):null;
        }
        $('Sktbn').onclick = function(){
            $('Skin_Peeler').style.display='flex';
            $('Sktbn').style.display='none';
        }
        var Skin_Peeler=document.getElementsByTagName('img');
        console.log(Skin_Peeler);
        for(var i=0;i<5;i++){
            Skin_Peeler[i].index= i+1;
            Skin_Peeler[i].onclick = function(){
            document.body.style.backgroundImage=`url('../images/z${this.index}.jpg')`;
            }
        }
        $('centen_box').onmouseleave = function(){
            $('Skin_Peeler').style.display='none';
            $('Sktbn').style.display='block';
        }
        // 轮播图




        for(i=5;i<9;i++){
            Skin_Peeler[i].onmouseover = function(){
                for(var j=5;j<9;j++){
                    Skin_Peeler[j].setAttribute('class','item');
                }
                
        
                this.setAttribute('class','active');
            }
        }
    }
    // 随机验证码
    // random函数获取min到max之间的整数
    // function random(max,min) {
    //     return Math.floor(Math.random()*(max-min)+min);
    // }
    // function name(params) {
    //     var code=''; 设置空模板
    // var codeLenght =4;   设置长度
    // var randomCode=[0,1,2,3,4,5,6,7,8,9,'A','B','C','D','E','F'
    // ,'H','I','J','K','L','M','N','O','P','Q','R','S','T','U','V','W','X'
    // ,'Y','Z']; 设置规则
    // for(var i=0;i<codeLenght;i++){   遍历循环4个验证码
    //     var index=random(0,36);  设置随机范围
    //     code+=randomCode[index];     每次点击的时候，对原code进行加
    // }
    // return code;

    // }
    